public class Islands {
    public static void main(String[] args) {
        int a[][] = new int[4][5];
//       a[0][0]=1;
//        a[0][1]=1;
//        a[1][0]=1;
//        a[1][1]=1;
//        a[2][2]=1;
//        a[]

        a[0][1] = 1;
        a[1][0] = 1;
        a[1][1] = 1;
        a[1][1] = 1;
        a[2][1] = 1;
        a[3][1] = 1;
        a[3][2] = 1;


        System.out.println(islandPerimeter(a));
        //  System.out.println(computeIslands(a));
    }

    public static void surrounding() {

    }

    public static int computeIslands(int a[]) {
        int islands = 0;
        return islands;

    }

    public static int islandPerimeter(int[][] grid) {
        int count = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {

                if (grid[i][j] == 1) {
                    if (j+1 >= grid[0].length || grid[i][j + 1] == 0) {
                        count++;
                    }
                    if (j-1 < 0 || grid[i][j - 1] == 0) {
                        count++;
                    }
                    if (i+1 >= grid.length || grid[i + 1][j] == 0) {
                        count++;
                    }
                    if (i-1 < 0 || grid[i - 1][j] == 0) {
                        count++;
                    }
                }

            }
        }
        return count;
    }
}
