import java.util.*;

public class ConcatAllWord {
    public static List<Integer> findSubstring(String s, String[] words) {


        ArrayList<Integer> result = new ArrayList<>();
        boolean update=true;

        if(s == null || s.isEmpty() || words.length == 0  ){
            return result;
        }
        HashMap<String,Integer> wordsMap= new HashMap<>();
        for(String word:words){
            if(wordsMap.containsKey(word)){
                wordsMap.put(word,wordsMap.get(word)+1);
            }
            else{
                wordsMap.put(word,1);
            }
        }

        int len = words[0].length();
        int wordCount=words.length;
        int i=0;
        int start=0;
        int count =0;
        HashMap<String,Integer> vm= new HashMap<>();
        while(i<=s.length()-len){

            update=true;
            String ss = s.substring(i,i+len);
            if(wordsMap.containsKey(ss)){
                count++;
                i+=len;

                if(vm.containsKey(ss)){
                    vm.put(ss,vm.get(ss)+1);
                }
                else{
                    vm.put(ss,1);
                }
                if(count==wordCount){

                    for(String p :wordsMap.keySet() ) {
                        if (!vm.containsKey(p) || wordsMap.get(p) != vm.get(p)) {

                            i = start + len;
                            start = i;
                            count = 0;
                            vm = new HashMap<>();
                            update=false;
                            break;

                        }
                    }
                    if(update) {
                        result.add(start);
                        i = start + len;
                        start = i;
                        count = 0;
                        vm = new HashMap<>();
                    }
                }

            }
            else{


                i=start+len;
                start=i;
                count =0;
                vm= new HashMap<>();
            }




        }
        System.out.println("ww");
        System.out.println("9".compareTo("7"));
        return result;
    }

    public static void main(String[] args) {

        String[]wors =
                {"fooo","barr","wing","ding","wing"};
       List<Integer> al=findSubstring("lingmindraboofooowingdingbarrwingmonkeypoundcake",wors );
        for (int i:
             al) {
            System.out.println(i);

        }



    }
}


