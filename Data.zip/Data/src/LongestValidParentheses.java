import java.util.Stack;

public class LongestValidParentheses {

    public int solution(String s) {

        char[] ch = s.toCharArray();
        boolean stack = false;
        int max = 0;
        int count = 0;
        Stack<Character> st = new Stack<Character>();

        for (int i = 0; i < ch.length; i++) {

            if (stack) {
                while (!st.empty()) {
                    if (st.pop() == ch[i]) {
                        count += 2;
                    }
                    else {
                        st.clear();
                        stack = false;
                    }
                }
                max = count > max ? count : max;
                stack=false;
             //   count=0;
            }

            if (ch[i] == '(') {
                st.push(ch[i]);
            } else {


                if (st.isEmpty()) {

                } else {
                    if(st.size()>1){
                        stack = true;
                        st.pop();
                        count += 2;
                        max = count > max ? count : max;
                    }
                    else{
                        st.pop();
                        count += 2;
                        max = count > max ? count : max;
                    }


                }
            }
        }

        return max;
    }

    public static void main(String[] args) {
        LongestValidParentheses parentheses = new LongestValidParentheses();
        System.out.println(parentheses.solution(")()())"));
    }
}
