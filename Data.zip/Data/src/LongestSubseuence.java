public class LongestSubseuence {
    public static void main(String[] args) {
        computeLongestSubSuquence();
        computeSequenceForAlphabets();
    }


    public static void computeLongestSubSuquence() {
        int arr[] = {3, 10, 2, 1, 20};
        int result[] = {1, 1, 1, 1, 1};
        int actualIndex[] = {0, 1, 2, 3, 4};
        for (int i = 1; i < arr.length; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[j] < arr[i]) {
                    if (result[i] < result[j] + 1) {
                        result[i] = result[j] + 1;
                        actualIndex[i] = j;

                    }
                }
            }
        }

        int max = 0;
        int maxIndex = 0;

        for (int i = 0; i < result.length; i++) {
            if (max < result[i]) {
                max = result[i];
                maxIndex = i;
            }

        }
        System.out.println(arr[maxIndex]);
        for (int k = 0; k < max - 1; k++) {
            maxIndex = actualIndex[maxIndex];
            System.out.println(arr[maxIndex]);
        }


    }

    //For Albhabets

    public static void computeSequenceForAlphabets() {

        String a = "BHCAIDE";
        char arr[] = a.toCharArray();
        int result[] = {1, 1, 1, 1, 1, 1, 1};
        int actualIndex[] = {0, 1, 2, 3, 4, 5, 6};

        for (int i = 1; i < arr.length; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[j] < arr[i]) {
                    if (result[i] < result[j] + 1) {
                        result[i] = result[j] + 1;
                        actualIndex[i] = j;


                    }
                }
            }
        }
        int max = 0;
        int maxIndex = 0;

        for (int i = 0; i < result.length; i++) {
            if (max < result[i]) {
                max = result[i];
                maxIndex = i;
            }

        }
        System.out.println(arr[maxIndex]);
        for (int k = 0; k < max - 1; k++) {
            maxIndex = actualIndex[maxIndex];
            System.out.println(arr[maxIndex]);

        }
    }
}
