import java.util.HashMap;
import java.util.HashSet;


public class LongestSubStringKDistinctCharcater {


    public static void main(String[] args) {

        longestSubstring("abcbbbbcccbdddadacb", 2);
    }

//Sliding Window technique
    public static int longestSubstring(String s, int k) {

        HashMap<Character,Integer> hs =new HashMap<Character, Integer>();
        int max =0;
        int i=0;
        int j =0;
        char ch[]= s.toCharArray();

        HashSet<Character> sanity =new HashSet<>();
        for(int x=0;x<ch.length;x++){
            sanity.add(ch[x]);
        }

        if(sanity.size()==k){
            return s.length();
        }
        while(j<ch.length){

            if(hs.size()<=k){
               if(hs.containsKey(s.charAt(j))){
                   hs.put(s.charAt(j),hs.get(s.charAt(j))+1);
                }
               else{
                   hs.put(s.charAt(j),1);
               }
                j++;
            }else{
               max=Math.max(max,j-i-1);
                System.out.println(s.substring(i,j-1) + " "+ max);

               for(int m=i;m<j;m++){
                   if(hs.get(s.charAt(m))>1){
                       hs.put(s.charAt(m),hs.get(s.charAt(m))-1);
                   }
                   else{
                       hs.remove(s.charAt(m));
                       i=m+1;
                      break;
                   }
               }
            }

        }




        return max;

    }
}

