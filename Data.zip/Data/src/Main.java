import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Main {


    static Set<Character> vowel= new HashSet<>();
    public static void main(String[] args) {

        String str1 = "aieef";
        String str2="klaief";
        vowel.add('a');
        vowel.add('e');
        vowel.add('i');
        vowel.add('0');
        vowel.add('u');
        LCS(str1,str2);
       // System.out.println("Longest common subsequence is"+ count);
    }

    public static int[][] LCS(String str1,String str2){


        int dp[][]= new int[str1.length()+1][str2.length()+1];
        System.out.println(dp.length);
        System.out.println(dp[0].length);

        for(int j=0;j<str2.length();j++){
            dp[0][j]=0;
        }
        for(int i=0;i<str1.length();i++){
            dp[i][0]=0;

        }
        for(int i=1;i<=str1.length();i++){
            for(int j=1;j<=str2.length();j++){
                if(str1.charAt(i-1)==str2.charAt(j-1) && checkVowel(str2.charAt(j-1))){
                    dp[i][j]=dp[i-1][j-1]+1;
                    System.out.println(str1.charAt(i-1));
                }
                else{
                    dp[i][j]= Math.max( dp[i-1][j],dp[i][j-1]);
                }
            }
        }

        int row= dp.length-1;
        int col=dp[0].length-1;
        char[] str = new char[3];
        int index = 3;

        System.out.println(row);
       while(row>0 && col>0 ){
           if(str1.charAt(row-1)== str2.charAt(col-1) &&  checkVowel(str2.charAt(col-1))){
     str[index-1]=str2.charAt(col-1);
     index--;
     row--;
             col--;


           }
           else if(dp[row][col-1]>dp[row-1][col]){
               col--;

           }
           else{
               row--;
           }

       }
        System.out.println(new String(str));
           return dp;

    }

    public static boolean checkVowel(Character ch){
        return vowel.contains(ch);

    }

}
