import java.sql.SQLOutput;
import java.util.Arrays;

public class PalidromeSubseq {
    public static void main(String[] args) {
        String haystack = "a", needle = "a";
        String[] arr={"flower","fmow","fliwer"};
        System.out.println(longestPalindromeSubseq("bbbab"));
        System.out.println(longestCommonPrefix(arr));
        System.out.println(strStr(haystack,needle));
    }
    public static int longestPalindromeSubseq(String s) {
        //Sliding Window
        int len = s.length();
        int[][] a= new int[len][len];
        char[] ch=s.toCharArray();

        for(int i=0;i<len;i++){
            a[i][i]=1;
        }
        for(int i=1;i<=len-1;i++){
            for(int j=0;j<=len-1-i;j++){
                if(ch[j]==ch[j+i])
                {
                    a[j][j+i]=a[j+1][j+i-1]+2;
                }
                else{
                    a[j][j+i]=Math.max(a[j][j+i-1],a[j+1][j+i]);
                }
            }


        }
        return a[0][len-1];

    }
    //dp solution
    public String longestPalindrome(String s) {
        int n = s.length();
        boolean[][] dp = new boolean[n][n];
        if (n == 0) {
            return "";
        }
        for (int i = 0; i < n; i++) {
            dp[i][i] = true;
        }
        String res = s.substring(0, 1);
        for (int len = 1; len < n; len++) {
            for (int i = 0; i < n - len; i++) {
                if (s.charAt(i) == s.charAt(i + len)) {
                    dp[i][i + len] = len == 1 ? true : dp[i + 1][i + len - 1];
                }

                if (dp[i][i + len] && len + 1 > res.length()) {
                    res = s.substring(i, i + len + 1);
                }

            }
        }
        return res;
    }

  /*  public String longestPalindrome(String s) {
        if (s.length() <= 1) {
            return s;
        }

        int after = findCurRepeatEndIndex(s, 0);
        String longestStr = s.substring(0, after);
        for (int cur = after; cur < s.length(); ) {
            after = findCurRepeatEndIndex(s, cur);

            String temp = findLongestLoop(s, cur - 1, after);
            if (temp.length() > longestStr.length()) {
                longestStr = temp;
            }

            cur = after;
        }

        return longestStr;
    }

    public int findCurRepeatEndIndex(String str, int cur) {
        int end = cur;
        while (end < str.length() && str.charAt(cur) == str.charAt(end)) {
            ++end;
        }
        return end;
    }

    public String findLongestLoop(String str, int before, int after) {

        while (before >= 0 && after < str.length() && str.charAt(before) == str.charAt(after)) {
            --before;
            ++after;
        }

        return str.substring(before + 1, after);
    }*/
  public static String longestCommonPrefix(String[] strs) {
      if(strs.length == 0)
          return "";
      Arrays.sort(strs);
      for(int i = 0; i< strs[0].length() ; i ++){
          if(strs[0].charAt(i) != strs[strs.length - 1].charAt(i))
              return strs[0].substring(0,i);
      }
      return strs[0];
  }

    public static int strStr(String haystack, String needle) {

        if (needle == null || needle.length() == 0)
            return 0;

        int len = needle.length();
        int index = -1;
        String str = "";
        char ch = needle.charAt(0);
        for (int i = 0; i <= haystack.length() - len; i++) {
            if (haystack.charAt(i) == ch) {
                str = haystack.substring(i, len + i);
                if (str.equals(needle))
                    return index;
                else{
                    str="";
                }
            }



        }
        return -1;
    }
    }

