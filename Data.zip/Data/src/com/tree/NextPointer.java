package com.tree;

public class NextPointer {
    public static Nod connect(Nod root) {

        Nod temp =root;
        if(root !=null)
            connect1(root);
        return root;


    }
    public static void connect1(Nod root){
        if(root!=null &&  root.left!= null){
            if(root.right!=null)
            {
                root.left.next=root.right;
                if(root.next !=null)
                {
                    if(root.next.left !=null)
                        root.right.next =root.next.left;
                    else
                        root.right.next =root.next.right;
                }
            }
                connect1(root.left);
            connect1(root.right);
        }

    }

    public static void main(String[] args) {
  Nod n=new Nod(1,new Nod(2,null,null,null),null,null);
        connect(n);
    }
}
class Nod {
    public int val;
    public Nod left;
    public Nod right;
    public Nod next;

    public Nod() {}

    public Nod(int _val) {
        val = _val;
    }

    public Nod(int _val, Nod _left, Nod _right, Nod _next) {
        val = _val;
        left = _left;
        right = _right;
        next = _next;
    }
};

//Take this as an example. If we connect the left first and then the right. We will have a connection sequence as following: 1->3, 0->4, 4->5, 9->10, 10->11. Now, we want to connect the 11 and 8. However, I will need the 5's next, which is 6 to do that. But, we haven't connect the 5 and 6 yet. Then the program will make 11's next as null. Then it will keep connecting 7->null, 5->6 and 8->12. But the 11 and 8 will not be connected. To avoid this, we connect everything from right to left to avoid the situation such that there's some nodes's next is null where should not be.
//        Hope that can be helpful.
//        : )
//
//        2
//        /  \
//        1     3
//        / \   /  \
//        0   4  5   6
//        /   / \    / \
//        9   10  11 8  12
//        /
//        7