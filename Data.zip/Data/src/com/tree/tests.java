package com.tree;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class tests {
    public static void main(String[] args) {
        List<String> list =new ArrayList<>();
      //  list=null;
        list.add("apple");
        //System.out.println(list.get(0));
        int a=0;
        int b=1;
     //   int c=b/a;
    //    System.out.println(c);

        for(Object object:list)
        {
            System.out.println(object);
        }
        list.forEach(System.out::println);
        for(int i= 0;i<list.size();i++){
            System.out.println(list.get(i));
        }
        Iterator it =list.iterator();
        if(it.hasNext()){
            System.out.println(it.next( )
            );
        }
    }

}
