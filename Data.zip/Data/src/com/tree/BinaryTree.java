package com.tree;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;

public class BinaryTree {
    Node first, middle, last, prev;

    // This function does inorder traversal
    // to find out the two swapped nodes.
    // It sets three pointers, first, middle
    // and last. If the swapped nodes are
    // adjacent to each other, then first
    // and middle contain the resultant nodes
    // Else, first and last contain the
    // resultant nodes
    void correctBSTUtil( Node root)
    {
        if( root != null )
        {
            // Recur for the left subtree
            correctBSTUtil( root.left);

            // If this node is smaller than
            // the previous node, it's
            // violating the BST rule.
            if (prev != null && root.key <
                    prev.key
            )
            {
                // If this is first violation,
                // mark these two nodes as
                // 'first' and 'middle'
                if (first == null)
                {
                    first = prev;
                    middle = root;
                }

                // If this is second violation,
                // mark this node as last
                else
                    last = root;
            }

            // Mark this node as previous
            prev = root;

            // Recur for the right subtree
            correctBSTUtil( root.right);
        }
    }

    // A function to fix a given BST where
    // two nodes are swapped. This function
    // uses correctBSTUtil() to find out
    // two nodes and swaps the nodes to
    // fix the BST
    void correctBST( Node root )
    {
        // Initialize pointers needed
        // for correctBSTUtil()
        first = middle = last = prev = null;

        // Set the poiters to find out
        // two nodes
        correctBSTUtil( root );

        // Fix (or correct) the tree
        if( first != null && last != null )
        {
            int temp = first.key;
            first.key = last.key;
            last.key = temp;
        }
        // Adjacent nodes swapped
        else if( first != null && middle !=
                null )
        {
            int temp = first.key;
            first.key = middle.key;
            middle.key = temp;
        }

        // else nodes have not been swapped,
        // passed tree is really BST.
    }

    /* A utility function to print
     Inoder traversal */
    void printInorder(Node node)
    {
        if (node == null)
            return;
        printInorder(node.left);
        System.out.print(" " + node.key);
        printInorder(node.right);
    }


    // Driver program to test above functions
    public static void main (String[] args)
    {
        /*   6
            / \
           10  2
          / \ / \
         1  3 7 12

        10 and 2 are swapped
        */

        Node root = new Node(6);
        root.left = new Node(10);
        root.right = new Node(2);
        root.left.left = new Node(1);
        root.left.right = new Node(3);
        root.right.right = new Node(12);
        root.right.left = new Node(7);

        System.out.println("Inorder Traversal"+
                " of the original tree");
//        BinaryTree tree = new BinaryTree();
//        tree.printInorder(root);
//
//        tree.correctBST(root);
//
//        System.out.println("\nInorder Traversal"+
//                " of the fixed tree");
//        tree.printInorder(root);
        int val=0;
 val =0<<1|1;
        System.out.println(val<<1|1);
        Node root1 = new Node(1);
        root1.left = new Node(0);
        root1.right = new Node(1);
        root1.left.left = new Node(0);
        root1.left.right = new Node(1);
        root1.right.right = new Node(1);
        root1.right.left = new Node(0);
        String s="";
        ArrayList<String> result = new ArrayList<>();

        dfs(root1,s,result);
        int ans=0;
        Iterator<String> it = result.iterator();
        while(it.hasNext()){
         String st =it.next();
            System.out.println(st);
         int len = st.length()-1;
         int count=0;
            for(int i=0;i<=len;i++){

                if(st.charAt(i)== '1')
                {
                    count+=Math.pow(2,len-i);
                }

            }
            System.out.println(count);
        ans+=count;
        }
        System.out.println(ans);

    }

    private static ArrayList<String> dfs(Node root, String s, ArrayList<String> result){

        if(root.left == null && root.right == null){
            s+=String.valueOf(root.key);
            result.add(s);
            return result;
        }
        s+=String.valueOf(root.key);
        dfs(root.left,s,result);
        dfs(root.right,s,result);

        return result;
    }
}