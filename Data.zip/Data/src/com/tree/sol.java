package com.tree;


 class TreeNode1 {
      int val;
      TreeNode1 left;
      TreeNode1 right;
      TreeNode1() {}
      TreeNode1 (int val) { this.val = val; }
      TreeNode1(int val, TreeNode1 left, TreeNode1 right) {
          this.val = val;
          this.left = left;
          this.right = right;
      }
  }

class sol {
    int sum =0;

    public int findTilt(TreeNode1 root) {
        postOrder(root);
        return sum;
//        if(root == null)
//            return  0;
//
////        TreeNode1 left = findTilt(root.left);
////        TreeNode1 right  = findTilt(root.right);
//        int l=nodeSum(root.left);
//        int r=nodeSum(root.right);
//
//        return Math.abs(l- r);



    }

    private int postOrder(TreeNode1 root) {
        if (root == null) return 0;

        int left = postOrder(root.left);
        int right = postOrder(root.right);

        sum += Math.abs(left - right);

        return left + right + root.val;
    }

    public static int nodeSum(TreeNode1 t){
        if(t == null)
            return 0;
        return nodeSum(t.left)+nodeSum(t.right)+t.val;
    }

    public static void main(String[] args) {

        TreeNode1 root = new TreeNode1(5,new TreeNode1(3,new TreeNode1(2,null,null),new TreeNode1(9,null,null)),new TreeNode1(3,new TreeNode1(2,null,null),new TreeNode1(9,null,null)));

        System.out.println(nodeSum(root));
    }
}



