package com.tree;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;



public class Solution1 {

    public List<Integer> getAllElements(TreeNode root1, TreeNode root2) {
        List<Integer> result = new ArrayList<>();
        ArrayList<Integer> a_input = new ArrayList<>();
        ArrayList<Integer> b_input = new ArrayList<>();
        ArrayList<Integer> a = getArray(root1, a_input);
        ArrayList<Integer> b = getArray(root2, b_input);

        int a_size = a.size();
        int b_size = b.size();

        int i = 0, j = 0;
        while (i < a_size && j < b_size) {

            if (a.get(i) <= b.get(j)) {
                result.add(a.get(i));
                i++;
            } else {
                result.add(b.get(j));
                j++;
            }
        }
        if (i < a_size) {
            while (i < a_size) {
                result.add(a.get(i));
                i++;
            }
        } else if (j < b_size) {
            while (j < b_size) {
                result.add(b.get(j));
                j++;
            }
        }
        return result;
    }

    public static ArrayList<Integer> getArray(TreeNode node, ArrayList<Integer> a) {

        if (node != null) {
            getArray(node.left, a);
            a.add(node.val);
            getArray(node.right, a);
        }
        return a;
    }

    public static void main(String[] args) {
        Solution1 s1 = new Solution1();
        TreeNode treenode1 = new TreeNode(2, new TreeNode(1), new TreeNode(4));
        TreeNode treenode2 = new TreeNode(1, new TreeNode(0), new TreeNode(3));
        TreeNode treenode3 = new TreeNode(8, new TreeNode(3, new TreeNode(1, null, null), new TreeNode(6, null, null)), new TreeNode(10));
        //  List<Integer> f =s1.getAllElements(treenode1,treenode2);


//        Iterator it = f.iterator();
//        while(it.hasNext()){
//            System.out.println(it.next());
        System.out.println(maxAncestorDiff(treenode3));


//        }
    }

    public static int maxAncestorDiff(TreeNode root) {
        int diff = Integer.MIN_VALUE;
        List<Integer> al = new ArrayList<Integer>();
        // return getDifference(root,diff,al);
        return 0;

    }
    //  public static int getDifference(TreeNode root,int diff){
//
//        if(root == null){
//            List<Integer> bl= new ArrayList<>();
//            for(int b :al){
//                bl.add(b);
//            }
//            Collections.sort(bl);
//            int curDiff=  Math.abs(bl.get(bl.size()-1)-bl.get(0));
//            System.out.println(curDiff);
//            return curDiff>diff?curDiff:diff;
//
//
//
//
//        }
//        al.add(root.val);
//        diff = getDifference(root.left,diff);
//        diff = getDifference(root.right,diff);
//        return diff;
//
//
//
//
//
//    }
//}

}
class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode() {
    }

    TreeNode(int val) {
        this.val = val;
    }

    TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}