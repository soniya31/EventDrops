package com.tree;

public class SpiralOrder {
}


class Solution {
    public int closedIsland(int[][] grid) {
        int count = 0;
        int rowEnd =grid.length-1;
        int colEnd  =grid[0].length-1;

        for (int col = 0;col< colEnd; col++) {

            if(grid[0][col]==0){
                checkSurrounding(grid,0,col);
            }
            if(grid[rowEnd][col]==0){
                checkSurrounding(grid,rowEnd,col);
            }

        }
        for (int row = 1;row<= rowEnd-1; row++) {

            if(grid[row][0]==0 ){
                checkSurrounding(grid,row,0);
            }
            if(grid[row][colEnd ]==0){
                checkSurrounding(grid,row,colEnd );
            }

        }
        for (int i = 0; i < rowEnd; i++) {
            for (int j = 0; j < colEnd; j++) {
                if (grid[i][j] == 0) {
                    count+=1;
                    checkSurrounding(grid,i,j);
                }
            }
        }
        return count;
    }

    public void checkSurrounding(int[][]  grid, int i ,int j){

        if(i<=0 || i>=grid.length-1 || j<=0 || j>=grid[0].length-1 || grid[i][j]==1 )
            return;

            grid[i][j] =1;
            checkSurrounding( grid, i ,j+1);
            checkSurrounding( grid, i ,j-1);
            checkSurrounding( grid, i+1,j);
            checkSurrounding( grid, i-1 ,j);
        }



}