package com.ll;


import apple.laf.JRSUIUtils;

import java.util.ArrayList;
import java.util.List;

class Solution1 {
   static List<Integer> list = new ArrayList<>();

    public static void main(String[] args) {
        TreeNode node =new TreeNode(2,new TreeNode(1),new TreeNode(3));
        System.out.println(increasingBST(node).right.val);
    }

    public static TreeNode increasingBST(TreeNode root) {

        computeInorderTransversal(root);

        TreeNode treenode1 =null;
        TreeNode treenode2 = null;

        if(list.size()>0){
            treenode1 = new TreeNode(list.get(0));
            treenode2=treenode1;
            for(int i=1;i<list.size();i++){
                treenode1.left=null;
                treenode1.right=new TreeNode(list.get(i));
                treenode1=treenode1.right;
            }
        }
        return treenode2;


    }
    private static void computeInorderTransversal(TreeNode root){

        if(root != null) {
            computeInorderTransversal(root.left);
            list.add(root.val);
            computeInorderTransversal(root.right);
        }

    }
}
class TreeNode{
    int val;
      TreeNode left;
      TreeNode right;
      TreeNode() {}
      TreeNode(int val) { this.val = val; }
      TreeNode(int val, TreeNode left, TreeNode right) {
          this.val = val;
          this.left = left;
          this.right = right;
     }
}