package com.ll;

import java.util.List;
import java.util.Stack;

class ListNode {
    int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next; }
  }
public class Solution {
    public boolean isPalindrome(ListNode head) {
        Stack<Integer> stack = new Stack<Integer>();

//        if(head == null || head.next == null){
//
//            return true;
//        }
        ListNode ref = head;
        while(ref!= null)
        {
            stack.push(ref.val);
            ref=ref.next;
        }
        while(head != null){

            if(head.val != stack.pop())
                return false;

        }

        return true;

    }


    public static void main(String[] args) {


        ListNode node = new ListNode(1);
    //    new Solution().isPalindrome(node);

        ListNode node2 = new ListNode(2);
        ListNode node3 = new ListNode(3);
        node.next   = node2;
        node.next=node3;
        testRecursionVars(node,1);

    }

   // static int n=0;

    public static ListNode testRecursionVars(ListNode node,int n){

        if(node == null){

            return null;
        }

        testRecursionVars(node.next,++n);
        if(n/2>=n){

            n=n-1;

        }

  return node;


    }
}
