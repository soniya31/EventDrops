package com.com.string;

import java.util.HashMap;

public class CircularString {
    static boolean rotateMatch(String s, String t) {
        int n = s.length();

        if (n != t.length()) // corner case
        {
            return false;
        }

        for (int i = 0; i<n; i++) // rotate
        {
            boolean match = true;

            for (int j = 0; j < n; j++) // match
            {
                if (s.charAt((i + j) % n) != t.charAt(j)) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
       // System.out.println(rotateMatch("ABCD","vghA"));
        String s = "dog cat cat dog";
        System.out.println( wordPattern("abba",s));

    }


    public static boolean wordPattern(String pattern, String str) {

        String[] sus =  str.split(" ");
        if(pattern.length() != sus.length)
            return false;

        HashMap<Character,String> hm = new HashMap<>();
        for(int i=0;i<pattern.length();i++){

            if(!hm.containsKey(pattern.charAt(i))){
                hm.put(pattern.charAt(i),sus[i]);
            }
            else{
                if( hm.get(pattern.charAt(i)).equals(sus[i]) )
                    return false;
            }

        }
        System.out.println(hm.size());
        return true;

    }

}
