package com.com.string;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Anagrams {
    public static boolean isAnagram(String s, String t) {

        if (s == null || t == null || s.length() == 0 || t.length() == 0)
            return false;

        if (s.length() != t.length())
            return false;

        //Sorting the string and check they are same

        char f1[] = s.toCharArray();
        char f2[] = t.toCharArray();

        Arrays.sort(f1);
        Arrays.sort(f2);
        System.out.println(f1.toString());
if(Arrays.equals(f1,f2)){
            return true;
        }
//        if (new String(f1).equals(new String(f2))) {
//            return true;
//        }

        return false;


    }
    public static boolean isAnagram1(String s, String t) {

        if(s==null || t== null )
            return false;

        if(s.length() != t.length())
            return false;

        //Sorting the string and check they are same

        char f1[]=s.toCharArray();
        char f2[]=t.toCharArray();

//      Arrays.sort(f1);
//         Arrays.sort(f2);
//         if(Arrays.equals(f1,f2)){
//             return true;
//         }

//         return false;


        HashMap<Character,Integer> hm = new HashMap<>();
        for(int i=0;i<f1.length;i++){

            if(hm.containsKey(f1[i])){
                hm.put(f1[i],hm.get(f1[i])+1);
            }else{
                hm.put(f1[i],1);
            }

        }
        for(int i=0;i<f2.length;i++){

            if(hm.containsKey(f1[i])){
                hm.put(f1[i],hm.get(f1[i])-1);
                if(hm.get(f1[i])<0)
                {
                    return false;
                }
            }
            else{
                return false;
            }


        }
//        if(){
////            return true;
////        }
////        else{
////            return false;
////        }
        return true;
    }

    public static  boolean isPalindrome(String s) {
        s=s.toLowerCase();
        char[] t= new char[s.length()];
        int j=0;
        for(int i=0;i<s.length();i++){
            if(Character.isDigit(s.charAt(i)) || Character.isLetter(s.charAt(i))){
                t[j++]=s.charAt(i);


            }

        }
        int len =j;
        int mid=(j-1)/2;
        for(int k=0;k<=mid;k++){
            if(t[k]!=t[len-1-k])
            {
                return false;
            }
        }

        return true;
    }

    public static List<String> fizzBuzz(int n) {
        List<String> list = new ArrayList<>();
        for(int i=1;i<=n;i++)
        {

            if(i%3==0 && i%5==0){
                list.add("FizzBuzz");
            }
            else if(i%3==0){
                list.add("Fizz");
            }
            else if(i%5==0){
                list.add("Buzz");
            }
            else{
                list.add(String.valueOf(i));
            }
        }
        return list;
    }


    public static String countAndSay(int n) {
        String j;
        if(n==1){
return "1";
        }
        else {
            j="11";
            for (int i = 3; i <= n; i++) {
                int len = j.length();
                int k = 0;
                int count = 1;
                String result = "";
                while (k < len - 1) {

                    int value = j.charAt(k);
                    if (j.charAt(k + 1) == value) {
                        count++;
                        k++;
                    } else {
                        result += String.valueOf(count) + j.charAt(k);
                        count = 1;
                        k++;


                    }
                }
                result += String.valueOf(count) + j.charAt(k);
                j = result;
                System.out.println(result + "for count " + i);
            }
        }
        return j;
    }


    public static List<List<Integer>> generate(int numRows) {
        List<List<Integer>> result = new ArrayList();
        for(int n=1;n<=numRows;n++){
            List<Integer> list = new ArrayList(n);
            list.add(1);
            if(n==1){

                result.add(list);
                // continue;
            }
            else if(n==2){
                list.add(1);
                result.add(list);
            }
            else{
                List<Integer> prev= result.get(n-2);

                for(int index=0;index<prev.size()-1;index++){
                    list.add(prev.get(index)+prev.get(index+1));
                }

                list.add(1);
                result.add(list);
            }


        }
        return result;
    }
    public static void main(String[] args) {
//        System.out.println( Anagrams.isAnagram1("anagram",
//                "nagaram"));

//        System.out.println(Anagrams.isPalindrome("A man, a plan, a canal: Panama"));
//        System.out.println(Integer.MIN_VALUE);
//        System.out.println(Integer.MAX_VALUE);
//        fizzBuzz(15);
     //   countAndSay(4);
        generate(4);
    }

}
