package com.com.string;

import java.util.ArrayList;

public class MinStack {
    ArrayList<Integer> stack = new ArrayList();
    ArrayList<Integer> min = new ArrayList();

    /** initialize your data structure here. */
    public MinStack() {

    }

    public void push(int x) {
        stack.add(x);
        if(min.size()== 0)
            min.add(x);
        else{
            if(min.get(min.size()-1)>x){
                min.add(x);
            }
        }

    }

    public void pop() {
        if(stack.size() != 0){
            int g= stack.get(stack.size()-1);
            stack.remove(stack.size()-1);
            if(min.get(min.size()-1) == g){
                stack.remove(min.size()-1);
            }



        }



    }

    public int top() {
        if(stack.size() != 0)
            return stack.get(stack.size()-1);

        return -1;

    }


    public int getMin() {

        if(min.size()  > 0)
            return min.get(min.size()-1);

        return -1;

    }

    public static void main(String[] args) {
         MinStack obj = new MinStack();
 obj.push(-2);
        obj.push(0);
        obj.push(-3);
        obj.getMin();
        obj.pop();
        obj.top();
        obj.getMin();




    }
}
