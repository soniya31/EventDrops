package com.com.string;

public class RemoveAllOccurrencesAbCString {
    // Function to remove all occurrences of "AB" and "C"
    // from the string
    public static String remove(String str)
    {
        char[] chars = str.toCharArray();

        // i maintains the position of current char in the input string
        // k maintains the next free position in output string
        int i = 0, k = 0;

        // do till we reach the end of the string
        while (i < str.length())
        {
            // if current char is 'B' and previous char (need not
            // be adjacent) was 'A', increment i and decrement k
            if (chars[i] == 'B' && (k > 0 && chars[k - 1] == 'A')) {
                --k;
                ++i;
            }
            // if current char is 'C', increment i
            else if (chars[i] == 'C') {
                ++i;
            }
            // for any other character, increment both i and k
            else {
                chars[k++] = chars[i++];
            }
        }

        System.out.println(chars);
        return new String(chars).substring(0, k);
    }

    // main function
    public static void main(String[] args)
    {
        String str = "CBAABBCAB";
String s="Abc GGHH, yunmn";
String[] a=s.split(" ");
        System.out.println(a[0]);

        System.out.println(a);
        System.out.println(s.charAt(1)-'0');
        str = remove(str);
        System.out.printf("String after removal of \"AB\" and \"C\" is \"%s\"", str);
    }
}
