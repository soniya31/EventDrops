package com.com.string;

public class SurroundedRegions {
    public void solve(char[][] board) {

        int rowEnd= board.length-1;
        if(rowEnd <= 0  )
            return;
        int colEnd=board[0].length-1;
        for(int row=0;row<=rowEnd;row++){
            if(board[row][0] =='O'){
                put2(board,row,0);
            }
            if(board[row][colEnd]=='O'){
                put2(board,row,colEnd);
            }
        }


        for(int col=0;col<=colEnd;col++){
            if(board[0][col] =='O'){
                put2(board,0,col);
            }
            if(board[rowEnd][col]=='O'){
                put2(board,rowEnd,col);
            }
        }



        for(int row= 0;row<=rowEnd;row++){
            for(int col=0;col<=colEnd;col++){
                if(board[row][col]=='O')
                    board[row][col]='X';
                if(board[row][col]=='*')
                    board[row][col]='O';


            }
        }
    }


    public void put2(char [][] grid, int i ,int j){

        if(i<0 || i>(grid.length-1) || j<0 || j>(grid[0].length-1) || grid[i][j] == 'X' || grid[i][j] == '*')
            return;

        grid[i][j] = '*';
        put2(grid,i,j-1);
        put2(grid,i,j+1);
        put2(grid,i+1,j);
        put2(grid,i-1,j);



    }

    public static void main(String[] args) {

        SurroundedRegions r = new SurroundedRegions();
        char[][] matrix ={{'O','O'},{'O','O'}};

        r.solve(matrix);
    }
}

