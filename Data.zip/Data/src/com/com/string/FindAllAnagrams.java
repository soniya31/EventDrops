package com.com.string;


import java.util.Arrays;

public class FindAllAnagrams {

    // Function to find all sub-strings of string X that are
    // permutations of string Y
    public static void findAllAnagrams(String X, String Y)
    {
        // m and n stores size of string Y and X respectively
        int m, n;

        char[] yChar=Y.toCharArray();
        Arrays.sort(yChar);
        // invalid input
        if ((m = Y.length()) > (n = X.length())) {
            return;
        }
        int y_length=Y.length();

        for(int i=0;i<X.length()-y_length;i++)
        {
            String prospects= X.substring(i,i+y_length);
            char[] pchar=prospects.toCharArray();
            Arrays.sort(pchar);
            System.out.println("*****");
            System.out.println(pchar);
            System.out.println(yChar);
            if(Arrays.equals(pchar,yChar)){
                System.out.println(pchar);
            }

        }

    }

    // main function
    public static void main(String[] args)
    {
        String X = "XYYZXZYZXXYZ";
        String Y = "XXYZ";

        findAllAnagrams(X, Y);
    }
}
