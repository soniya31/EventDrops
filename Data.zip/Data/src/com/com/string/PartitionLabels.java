package com.com.string;

import java.util.*;

public class PartitionLabels
{
    public static void main(String[] args) {
         String s = "eaaaabaaec";

     //   System.out.println(getHint("1123","0111"));
      //  System.out.println(compareVersion1("1.1.2","1.1"));
       List<Integer> list=partitionLabels(s);


    }


    public static String getHint(String secret, String guess) {

        int bull_A=0;
        int cows_B=0;

        Map<Character,Integer> set = new HashMap<>();
        for(int i=0;i<guess.length();i++){
            if(guess.charAt(i) == secret.charAt(i)) {
                bull_A++;
            }
            else {
                if(set.containsKey(guess.charAt(i))) {
                    set.put(guess.charAt(i), set.get(guess.charAt(i)) + 1);
                } else {
                    set.put(guess.charAt(i), 1);
                }
            }
        }

        for(int i=0;i<secret.length();i++){
            if(guess.charAt(i) != secret.charAt(i)) {
                if (set.containsKey(secret.charAt(i))) {
                    if (set.get(secret.charAt(i)) > 0) {
                        cows_B++;
                        set.put(secret.charAt(i), set.get(secret.charAt(i)) - 1);
                    }

                }
            }
            }


        StringBuilder sb = new StringBuilder();
        sb.append(bull_A).append("A").append(cows_B).append("B");
        return sb.toString();
    }

    public static int compareVersion(String version1, String version2) {
        String[] v1  =  version1.split("\\.");

        String[] v2  =  version2.split("\\.");

        int v1_len= v1.length;
        int v2_len = v2.length;

        int loop = v1_len>v2_len?v2_len:v1_len;

        for(int i=0;i<loop;i++){
            int v_1=Integer.parseInt(v1[i]);
            int v_2=Integer.parseInt(v2[i]);

            if(v_1 > v_2){
                return 1;
            }
            else if(v_1 < v_2){
                return -1;
            }

        }
        if(v1_len == v2_len )
            return 0;

        if(v1_len<v2_len)
            return -1;

        return 1;

    }
    public static int compareVersion1(String version1, String version2) {
        String[] v1  =  version1.split("\\.");
        String[] v2  =  version2.split("\\.");


        int loop = Math.max(v1.length,v2.length);

        for(int i=0;i<loop;i++){
            String v_1 = i<v1.length-1?v1[i]:"0";
            String v_2 = i<v2.length-1?v2[i]:"0";

            if(v_1.compareTo(v_2) != 0){
                return v_1.compareTo(v_2);
            }

        }
        return 0;
    }

    String s = "eaaaabaaec";
    public List<Integer> partitionLabels1(String S) {
        if(S == null || S.length() == 0){
            return null;
        }
        List<Integer> list = new ArrayList<>();
        int[] map = new int[26];  // record the last index of the each char

        for(int i = 0; i < S.length(); i++){
            map[S.charAt(i)-'a'] = i;
        }
        // record the end index of the current sub string
        int last = 0;
        int start = 0;
        for(int i = 0; i < S.length(); i++){
            last = Math.max(last, map[S.charAt(i)-'a']);
            if(last == i){
                list.add(last - start + 1);
                start = last + 1;
            }
        }
        return list;
    }
    public static List<Integer> partitionLabels(String S) {

        List<Integer> list = new ArrayList<>();
        Map<Character,Track> map = new LinkedHashMap<>();
        for(int i=0;i<S.length();i++){
            if(map.containsKey(S.charAt(i))){
                Track t= map.get(S.charAt(i));
                t.setEnd(i);
                map.put(S.charAt(i),t);
            }
            else{
                map.put(S.charAt(i),new Track(i,i));
            }
        }

        Set<Map.Entry<Character,Track>> set = map.entrySet();

        Iterator<Map.Entry<Character,Track>> it =  set.iterator();
        int b=0,e=0;
        Track t = map.get(S.charAt(0));
        b = t.getBegin();
        e = t.getEnd();

      while(it.hasNext()){
            Map.Entry<Character,Track> m = it.next();
            Track sus = m.getValue();

            if(sus.getEnd()<=e && sus.getBegin()>=b){
                continue;
            }
            else if(sus.getBegin()>=b && sus.getBegin()<=e && sus.getEnd()>e){
                e=sus.getEnd();
            }
             else if(sus.getBegin()>e){

                 list.add(e-b+1);
                 b=sus.getBegin();
                 e=sus.getEnd();
            }
        }
     // if(!written)
          list.add(e-b+1);

        list.forEach((n) -> System.out.println(n));

        return list;

    }

}


class Track{

    int begin;
    int end;
    Track(int begin,int end){
        this.begin= begin;
        this.end = end;
    }

    public int getBegin() {
        return begin;
    }

    public void setBegin(int begin) {
        this.begin = begin;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }


}
