package com.com.string;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;

public class HashUtil {

    public static String generateHash(String filamentId)  {
        String filamentHash = null;
        try {
            if (filamentId != null) {
                filamentHash = String.format("%064x", new java.math.BigInteger(1,
                        MessageDigest.getInstance("SHA-256").digest(filamentId.getBytes("UTF-8"))));

            }
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException ex) {

        }
        return filamentHash;
    }

    public static void main(String[] args) {

      //  readAndInsert("/Users/schopr12/Si");
        try {
            BufferedReader  br = new BufferedReader(new FileReader("/Users/schopr12/Downloads/providers_hcs/HealthServiceCase.csv"));
            String line = br.readLine();



            while(line != null ){
//                   String filamentId = "FLB_SRCIDF_" + "CSP_Facets".toUpperCase() + (line.trim()).toUpperCase();
//                      String id = HashUtil.generateHash(filamentId);
//                      System.out.println(id);
//                      line=br.readLine();
                String arr[]=line.split(";");
                System.out.println(arr[0]);
                line=br.readLine();
            }





        }
        catch (Exception e){
            // "87f834ade87a6a9c052f36b0335abce6c242c3bf7eeab1c406aac973ba74f50a"
        }

    }


    private static void readAndInsert(String path) {
        try {
            String out_path = "/Users/schopr12/Si_out";
            //insert edge
            File files = new File(path);
            File[] fileList = files.listFiles();
            for (File file : fileList) {
                if (file.isDirectory()) {
                    System.out.println("Inside directory--" + file.getAbsolutePath());
                    readAndInsert(file.getAbsolutePath());
                    continue;
                }
                String fName = file.getName();

                if (file.getName() != "") {
                    // fName = fName.substring(0,fName.indexOf("."));
                    FileWriter fileWriter = new FileWriter(out_path+"/"+fName);
                    System.out.println("FileName::::---" + fName);

                    BufferedReader  br = new BufferedReader(new FileReader("/Users/schopr12/Si"+"/"+fName));
                    BufferedWriter bw = new BufferedWriter(fileWriter);
                    String line = br.readLine();
                    while(line != null ){
                        String filamentId = "FLB_SRCIDF_" + "CSP_Facets".toUpperCase() + (line.trim()).toUpperCase();
                        String id = HashUtil.generateHash(filamentId);
                        bw.write(id);
                        bw.newLine();
                        line=br.readLine();



            }
        }

            }
        } catch (Exception e) {
            // "87f834ade87a6a9c052f36b0335abce6c242c3bf7eeab1c406aac973ba74f50a"
        }

    }
}

