package com.bfs;
//
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.*;

import java.util.*;
import java.util.stream.Collectors;

public class js {
    public static void main(String[] args) {
        int[] a = {2147483647, -2147483647};
        int[] b = {9, 0, 7, 7};

        //  System.out.println( containsNearbyAlmostDuplicate(a,1,2147483647));
        //     System.out.println(repeatedSubstringPattern("aba"));
       // System.out.println(largestTimeFromDigits(b));
        System.out.println(3/10);

        System.out.println(addDigits(38));
    }

    public static boolean containsNearbyAlmostDuplicate(int[] nums, int k, int t) {

        for (int i = 0; i < nums.length - 1; i++) {
            for (int j = i + 1; j < nums.length; j++) {

                long no = (long) nums[i] - (long) nums[j];

                if (Math.abs(no) <= t) {
                    if (Math.abs(j - i) <= k) {
                        return true;
                    }
                }
            }

        }
        return false;
    }

    public static boolean repeatedSubstringPattern(String s) {
        for (int i = 1; i <= s.length() / 2; i++) {
            String sub = s.substring(0, i);

            int mul = s.length() / i;
            String str = "";
            for (int j = 0; j < mul; j++) {
                str = str + s.substring(0, i);
            }
            if (s.equals(str))
                return true;
        }
        return false;


    }

    public static String largestTimeFromDigits(int[] A) {
        Set<Integer> list = new HashSet<>();
        List<String> orginalSet = new ArrayList<>();
        int i;
        for (i = 0; i < A.length - 1; i++) {
            orginalSet.add(String.valueOf(A[i]));
            for (int j = i + 1; j < A.length; j++) {

                String a = String.valueOf(A[i]) + String.valueOf(A[j]);
                int b = Integer.parseInt(a);
                if (b < 24) {
                    list.add(b);
                }

                a = String.valueOf(A[j]) + String.valueOf(A[i]);
                b = Integer.parseInt(a);
                if (b < 24) {
                    list.add(b);
                }
            }
        }
        orginalSet.add(String.valueOf(A[i]));
        List<Integer> set = new ArrayList<>(list);
        Comparator c = Collections.reverseOrder();
        Collections.sort(set, c);

        if (set.size() <= 0) {
            return "";
        }
        Iterator it = set.iterator();

        while (it.hasNext()) {
            List<String> newSet = orginalSet.stream().collect(Collectors.toList());
            StringBuilder sb = new StringBuilder();
            int pros = (int) it.next();
            String a = String.valueOf(pros);
            if (a.length() == 1) {
                sb.append("0");
                newSet.remove("0");
            }
            sb.append(a);
            sb.append(":");
            for (int k = 0; k < a.length(); k++) {
                String qa = Character.toString(a.charAt(k));
                newSet.remove(qa);

            }

            int n = newSet.size();

            String arr[] = new String[n];

            arr = newSet.toArray(arr);

            String e = String.valueOf(arr[0]) + String.valueOf(arr[1]);
            String f = String.valueOf(arr[1]) + String.valueOf(arr[0]);


            if ((Integer.parseInt(f) < 60 && Integer.parseInt(e) < 60)) {
                if (Integer.parseInt(e) < Integer.parseInt(f)) {

                    sb.append(f);
                    return sb.toString();

                } else {
                    sb.append(e);
                    return sb.toString();
                }
            } else if (Integer.parseInt(f) < 60) {


                sb.append(f);
                return sb.toString();


            } else if (Integer.parseInt(e) < 60) {
                sb.append(e);
                return sb.toString();

            }

        }

        return "";
    }

    public static int addDigits(int num) {


        if(num/10 == 0 )
            return num;

        int sum=0;
        while(num>0){
            int s= num%10;
            sum+=s;
            num = num/10;
        }

      return addDigits(sum);




    }
}
