package com.bfs;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

public class SnakeAndLadder {

     static Map<Integer, Integer> ladder = new HashMap<>();
    static Map<Integer, Integer> snake = new HashMap();
     public static void main(String[] args) {

        // snakes and ladders are represented using a map.
        // insert ladders into the map
        ladder.put(1, 38);
        ladder.put(4, 14);
        ladder.put(9, 31);
        ladder.put(21, 42);
        ladder.put(28, 84);
        ladder.put(51, 67);
        ladder.put(72, 91);
        ladder.put(80, 99);

        // insert snakes into the map
        snake.put(17, 7);
        snake.put(54, 34);
        snake.put(62, 19);
        snake.put(64, 60);
        snake.put(87, 36);
        snake.put(93, 73);
        snake.put(95, 75);
        snake.put(98, 79);


    }

    public static int findSolution(){

         int[] v ={1,2,3,4,5,6};
         Queue<Node> que =new ArrayDeque<>();

        boolean[] visited = new boolean[100];

         que.add(new Node(0,0));

         visited[0]=true;

         while(!que.isEmpty()){
             Node n= que.poll();
             System.out.println(n.val);
             if(n.val==99)
                 return n.thr;

             for(int i=0;i<6;i++){

                 int current=n.val+v[i];
                 int _snake =  snake.get(current) != null?snake.get(current):0;
                 int _ladder =  ladder.get(current) != null?ladder.get(current):0;

                 //at a time only one of the option will be true
                 current = _snake != 0 ?_snake:current;
                 current = _ladder != 0 ?_ladder:current;

                if(current<100 && !visited[current]) {
                    que.add(new Node(current,n.thr+1));
                        visited[current]=true;
                 }
             }
         }

         return Integer.MAX_VALUE;
    }

}

class Node{
    int val;
    int thr;
    Node(int val , int thr){
        this.val=val;
        this.thr=thr;
    }

}