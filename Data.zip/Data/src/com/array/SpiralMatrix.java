package com.array;

public class SpiralMatrix {
    public static int[][] generateMatrix(int n) {
        int row_start=0;
        int row_end=n-1;

        int[][] result =new int[n][n];
        int count =0;

        while(row_start<=row_end)
        {
            for(int i=row_start,j=row_start;j<=row_end;j++){
                result[i][j]=++count;
            }
            if(row_start+1<=n-1){
                for(int i=row_start+1,j=row_end;i<=row_end;i++){
                    result[i][j]=++count;
                }
            }
                if(row_end-1>=0){
                    for(int i=row_end,j=row_end-1;j>=row_start;j--){
                        result[i][j]=++count;
                    }
                }
                if(row_end-1>=0 && row_start+1<=n-1){
                    for(int i=row_end-1,j=row_start;i>=row_start+1;i--){
                        result[i][j]=++count;
                    }
                }
            row_start+=1;
            row_end-=1;
        }

        return result;

    }

    public static void main(String[] args) {
    generateMatrix(3);



    }
}

