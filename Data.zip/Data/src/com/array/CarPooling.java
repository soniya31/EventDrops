package com.array;

import java.util.ArrayList;

public class CarPooling {
    public static void main(String[] args) {
        ArrayList<Conf> al = new ArrayList<>();



    }



}

class Conf{
    int filled;
    int start;
    int end;

}
