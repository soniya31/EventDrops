package com.array;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class BrustBalloon {
    public static void main(String[] args) {
        int[] a = {3,1,5,8};
        maxCoins(a);
    }
    public static int maxCoins(int[] nums) {
        int total=0;
        TreeMap<Integer,Integer> map = new TreeMap<>();
        for(int i=1;i<nums.length-1;i++){
            map.put(nums[i],i);
        }
        Iterator it = map.entrySet().iterator();
        while(it.hasNext()){

            Map.Entry<Integer,Integer> m = (Map.Entry)it.next();

            int index=m.getValue();
            int lower = index-1;
            int high = index+1;
            while(lower>0){
                if(nums[lower]==-1){
                    lower--;
                }
                else{
                    break;
                }
            }
            while(high<nums.length-1){
                if(nums[high]==-1){
                    high++;
                }
                else{
                    break;
                }
            }
            total =total+nums[lower]*nums[high]*nums[index]   ;
            System.out.println(total);
            nums[index] = -1;
        }
        if(nums[0]>=nums[nums.length-1]){
            total =total+nums[0]*nums[nums.length-1]+nums[0];
            System.out.println(total);

        }
        else{
            total =total+nums[0]*nums[nums.length-1]+nums[nums.length-1];
            System.out.println(total);

        }

        return total;
    }
}
