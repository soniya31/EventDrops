package com.array;

public class GasStation {

    public static void main(String[] args) {

        int[] gas={5,8,2,8};
        int[] cost ={6,5,6,6};
        System.out.println( canCompleteCircuit(gas,cost));
    }
    public static  int canCompleteCircuit(int[] gas, int[] cost) {
        int len = gas.length;
        for(int i=0;i<len;i++)
        {
            if(gas[i]>cost[i]){
                int a =  checkUniqueSol(i,gas,cost);
                if(a>=0){
                    return i;
                }
            }

        }
        return -1;

    }

    public  static int checkUniqueSol(int j,int[] gas,int[] cost){

        int initial = 0;
        int rem = 0;
        for(int i = j;i<gas.length;i++){
            rem = initial + gas[i] - cost[i];
            if(rem < 0)
                return -1;
            initial =rem;

        }
        for(int i = 0;i<j;i++){
            rem = initial + gas[i] - cost[i];
            if(rem < 0)
                return -1;
        }
        if(rem >= 0)
            return rem;

        return -1;


    }
}
