package com.array;

public class RemoveDuplicatesfromSortedArray {

    public static void main(String[] args) {
        int[] a = {1,1,1,1,2,2,2,3,3,4};
        removeDuplicates(a);
    }
    public static int removeDuplicates(int[] nums) {
        if(nums.length == 0)
            return 0;
        if(nums.length == 1 || nums.length == 2 )
            return nums.length;

        int prev = nums[0];
        int i = 1;
        boolean pair = false;
        while(i<nums.length){
            if(!pair && prev == nums[i]){

                pair=true;


            }
            else if(prev != nums[i] ){
                prev=nums[i];
                pair= false;

            }
            else{
                nums[i]=-100000;
            }
            i++;
        }

        int count = 0;
        for(int j=0;j<nums.length-1;j++){
            if(nums[j]==-100000)
            {
                int temp =nums[j];
                nums[j]=nums[j+1];
                nums[j+1]=temp;
            }
            else{
                count++;
            }
        }
        return count;

    }
}
