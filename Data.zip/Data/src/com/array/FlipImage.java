package com.array;


import java.util.ArrayList;
import java.util.List;

public class FlipImage {


    public static void main(String[] args) {
        int a[][] ={{0,1,0,1,1,},{1,0,1,0,0}};

        List<Integer> al = new ArrayList<>();


    }
    public int getDifference(int diff){
        String s=null;
            if(s == null){


        return diff;
    }

        return  diff = getDifference(diff);
       //return diff = getDifference(diff);





}
}
