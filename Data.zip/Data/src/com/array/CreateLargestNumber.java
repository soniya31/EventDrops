package com.array;



import javax.sound.midi.Soundbank;
import java.lang.reflect.Array;
import java.sql.SQLOutput;
import java.util.*;

public class CreateLargestNumber {


    public static void main(String[] args) {
        int[] b ={121,12};
        System.out.println(printLargest(b));

    }




    //Most appropiate way
    static String printLargest(int[] arr){

     ArrayList<String> a = new ArrayList<>();

        for(int i=0;i<arr.length;i++){
            a.add(String.valueOf(arr[i]));

        }
        Collections.sort(a, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                String XY= o1+o2;
                String YX= o2+o1;

                return XY.compareTo(YX)>0?-1:1;
            }
        });


        Iterator it = a.iterator();
StringBuilder sb = new StringBuilder();
        while(it.hasNext())
            sb.append(it.next());

        String ans = sb.toString();
        int i=0;
        while(i<ans.length()){
            if(ans.charAt(i) != '0')
                break;
            i++;
        }
        StringBuilder sb_final = new StringBuilder(ans);
        sb_final.replace(0,i,"");

        return sb_final.toString();


    }
    public String largestNumber(int[] nums) {

        TreeMap<Integer, ArrayList<Integer>> treeMap = new TreeMap<>(Collections.reverseOrder());

        for(int i=0;i<nums.length;i++){

            String a = String.valueOf(nums[i]);
            char r = a.charAt(0);
            if(treeMap.containsKey(Integer.parseInt(String.valueOf(r)))){

                ArrayList<Integer> arr=  treeMap.get(Integer.parseInt(String.valueOf(r)));
                arr.add(nums[i]);

            }
            else{
                ArrayList<Integer> arr = new ArrayList<>();
                arr.add(nums[i]);
                treeMap.put(Integer.parseInt(String.valueOf(r)),arr);
            }

        }

        Set<Map.Entry<Integer, ArrayList<Integer>>> set = treeMap.entrySet();
        Iterator<Map.Entry<Integer, ArrayList<Integer>>> it = set.iterator();
        StringBuilder sb = new StringBuilder();

        while(it.hasNext()){
            Map.Entry<Integer, ArrayList<Integer>> m = it.next();
            sb.append(computeOrderedString(m.getValue()));

        }
        int i = 0;
        while (i < sb.length()-1  ){
            if(sb.charAt(i) != '0')
                break;
            i++;

        }
        // Convert str into StringBuffer as Strings
        // are immutable.
        StringBuffer buffer = new StringBuffer(sb);

        // The  StringBuffer replace function removes
        // i characters from given index (0 here)
        buffer.replace(0, i, "");

        return buffer.toString();
    }
    public static java.lang.String computeOrderedString(ArrayList<Integer> arr){
        StringBuilder sb = new StringBuilder();
        Iterator<Integer> it =arr.iterator();
        ArrayList<Integer> zeroList = new ArrayList<>();
        ArrayList<Integer> nonzeroList = new ArrayList<>();
        while(it.hasNext()){
            int a = it.next();
            if(a%10 == 0){
                zeroList.add(a);

            }
            else{
                nonzeroList.add(a);
            }


        }
        String max ="";
        Collections.sort(zeroList);
        if(nonzeroList.size()>0){
            Collections.sort(nonzeroList,Collections.reverseOrder());
            max = Integer.toString(nonzeroList.get(0));
            for(int i=1;i<nonzeroList.size();i++) {
                StringBuilder sb1 = new StringBuilder();
                StringBuilder sb2 = new StringBuilder();
                sb1.append(max).append(nonzeroList.get(i));
                sb2.append(nonzeroList.get(i)).append(max);

                if (sb1.toString().compareTo(sb2.toString()) > 0) {
                    max = sb1.toString();
                } else {
                    max = sb2.toString();
                }
            }


        }




//         for(int i=0;i<nonzeroList.size();i++){
//             sb.append(nonzeroList.get(i));
//         }
        for(int i=0;i<zeroList.size();i++){

            sb.append(zeroList.get(i));
        }

        return max.compareTo(sb.toString())>1?max+sb.toString(): sb.toString()+max;


    }


}

