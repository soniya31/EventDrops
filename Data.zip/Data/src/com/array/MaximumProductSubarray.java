package com.array;

import java.util.ArrayList;
import java.util.Arrays;

public class MaximumProductSubarray {
   // int[] a = {-2,3,-4};

    public static int maxProduct1(int[] nums) {
     int max_true=Integer.MIN_VALUE;
     int m = nums[0];
        for(int i=1;i<nums.length;i++){
            m*=nums[i];
            if(m>max_true){
                max_true=m;

            }
            else{
                m=1;

            }

        }
        Arrays.sort(nums);
        return Math.max(max_true,nums[nums.length-1]);
    }

    public static int maxSum(int[] nums) {

        int max_so_far = 0;
      int  max_ending_here = 0;

        for(int i=0; i < nums.length; i++){
        max_ending_here= max_ending_here+nums[i];
        if(max_ending_here > max_so_far)
            max_so_far=max_ending_here;
        if(max_ending_here < 0)
            max_ending_here = 0;
        }
        return max_so_far;




    }
    public static int maxSum1(int[] nums) {
          int[] b= {-2,-3,4,-1,-2,1,5,-3};
        int max_so_far = nums[0];
        int max = Integer.MIN_VALUE;
        ;
        for (int i = 1; i < nums.length; i++) {
            max_so_far = max_so_far + nums[i];
            if (max_so_far < nums[i]) {

                max_so_far = nums[i];

            }
            if (max < max_so_far)
                max = max_so_far;

        }
        return max;
    }
// int[] a = {-2,3,-4};
    public static int maxProduct(int[] nums) {
        int max_true = Integer.MIN_VALUE;
        boolean cont = false;
        int m = 1;
        int i=0;
        while ( i < nums.length ) {

            if (!cont) {
                m = nums[i] * m;
                if (m > max_true) {
                    max_true = m;
                    cont = true;
                  i+=1;
                } else {
//                    m=Math.max(nums[i],nums[i+1]);
//                    max_true = Math.max(m,   max_true);
                    cont = false;
                    i++;
                }

            } else {
                m = nums[i] * m;
                if (m > max_true) {
                    max_true = m;
                    cont = true;
                    i++;
                } else {
                    cont = false;


                }
            }

        }
        Arrays.sort(nums);
        return Math.max(max_true,nums[nums.length-1]);
    }

    public static void main(String[] args) {
        int[] a = {-2,3,-4};
       // System.out.println(maxProduct1(a));
      //  int[] b= {8,-3,4,-1,-2,1,5,-3};
       // System.out.println(maxSum(b));
        System.out.println(0%2);

    }
}
