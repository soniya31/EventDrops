package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Conversion {
    public static void main(String[] args) {

//        File file =new File("/Users/schopr12/Desktop/tiger_dd_small_csv.csv");
//        try (InputStream in = new FileInputStream(file);) {
//            CSV csv = new CSV(true, ',', in );
//            List < String > fieldNames = null;
//            if (csv.hasNext()) fieldNames = new ArrayList < > (csv.next());
//            List < Map < String, String >> list = new ArrayList < > ();
//            while (csv.hasNext()) {
//                List < String > x = csv.next();
//                Map < String, String > obj = new LinkedHashMap < > ();
//                for (int i = 0; i < fieldNames.size(); i++) {
//                    obj.put(fieldNames.get(i), x.get(i));
//                }
//                list.add(obj);
//            }
//            ObjectMapper mapper = new ObjectMapper();
//            mapper.enable(SerializationFeature.INDENT_OUTPUT);
//            mapper.writeValue(System.out, list);
//        }
//        catch(Exception e){
//            System.out.println(
//              e.getMessage()
//            );
//
//        }
    }
}
