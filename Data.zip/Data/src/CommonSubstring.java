public class CommonSubstring {
}
