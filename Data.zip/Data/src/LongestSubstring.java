import java.util.HashMap;
import java.util.HashSet;

public class LongestSubstring {


    public static void main(String[] args) {
        int a = 'a';
        System.out.println( convert("PAYPALISHIRING",3));

    }
    public static int lengthOfLongestSubstring(String s) {
        char arr[]= s.toCharArray();

        HashSet<Character> hs =new HashSet<Character>();
        int count =0;
        int max =0;
        for(int i=0;i<arr.length;i++){
            if(!hs.contains(arr[i]))
            {
                hs.add(arr[i]);
                count++;
            }
            else{

                max=max<count?count:max;

                hs =new HashSet<Character>();
                hs.add(arr[i]);
                count =1;

            }
        }
        return max;
    }

    public static  int lengthOfLongestSubstring1(String s) {

        if(s == null)
            return 0;
        if(s.length()<=0)
            return 0;
        int i=0,j=0;
        char ch[] = s.toCharArray();
        int len = s.length();
        int count=0;
        HashMap<Character,Integer> hm =new HashMap<Character,Integer>();
        while(i<len && j<len ){
            if(hm.containsKey(ch[j])){
                i=Math.max(hm.get(ch[j])+1,1);
            }
            hm.put(ch[j],j);
            count = Math.max(count,j-i+1);
            j++;




        }
        return count;
    }

    public static String convert(String s, int numRows) {

        String[] str = new String[numRows];
        char[] ch = s.toCharArray();

        boolean down1 = true;
        int row =0;
        String result="";
        for(int j=0;j<str.length;j++){
          str[j] ="";
        }

        for(int i=0;i<ch.length ;i++){

            str[row]+=ch[i];

            if(row == numRows-1){
                down1 = false;

            }
            if(row == 0){
                down1 =true;
            }

            if(down1)
                row++;
            else
                row--;
        }

        for(int j=0;j<str.length;j++){
            result= result+str[j];
        }
        return result;

    }

//r3 = string1;

   // Input: str = "GEEKSFORGEEKS"
   // n = 3
//    public void zigzagConversion(){
//        java.lang.String str = "GEEKSFORGEEKS";
//        int  n = 3;
//
//        StringBuffer sb1=new StringBuffer();
//        StringBuffer sb2=new StringBuffer();
//        StringBuffer sb3=new StringBuffer();
//        boolean b1=false;
//        boolean b2=false;
//        boolean b3=false;
//
//
//        for(int i=0;i<str.length();i++){
//         if(b1){
//             sb1.append(str.charAt(i));
//             b1=false;
//             b2=true;
//             b3=false;
//         }
//         else if(b2){
//             sb2.append(str.charAt(i));
//             b1=false;
//             b2=false;
//             b3=true;
//         }
//         else if(b3){
//             sb3.append(str.charAt(i));
//             b1=false;
//             b2=true;
//             b3=false;
//         }
//
//        }
//
//
//
//    }

}



//        if(s.length() <= 1) return s.length();
//
//                HashMap<Character, Integer> charsLastIndexMap = new HashMap<>();
//
//        int windowStartIndex = 0;
//        int windowEndIndex = 0;
//
//        int maxLen = 0;
//
//        for(windowEndIndex=0; windowEndIndex<s.length(); windowEndIndex++){
//
//        char currChar = s.charAt(windowEndIndex);
//
//        if(charsLastIndexMap.containsKey(currChar)){
//        windowStartIndex = Math.max(windowStartIndex, charsLastIndexMap.get(currChar) + 1); //Move start of window
//        }
//
//        maxLen = Math.max(maxLen, windowEndIndex - windowStartIndex + 1);                       //Update maxLen
//        charsLastIndexMap.put(currChar, windowEndIndex);
//        }
//
//        return maxLen;