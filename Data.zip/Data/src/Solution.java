
  class ListNode {
      int val;
      ListNode next;
      ListNode(int x) { val = x;
      next=null;}

  }public class Solution {
      public ListNode addTwoNumbers(ListNode l1, ListNode l2) {

          int len1=getListLength(l1);
          int len2=getListLength(l2);

          ListNode r=new ListNode(0);
          ListNode tracker =r;
          if(len1<len2){
              int diff=len2-len1;

              l1=addPadding(diff,l1);
          }
          if(len1>len2){
              int diff=len1-len2;
              l2=addPadding(diff,l2);
          }


              int carry=0;

              while(l1 != null  ){
                  int sum = l1.val+l2.val+carry;
                   carry = sum>=10?1:0;
                  ListNode result =new ListNode(sum%10);
                  l1=l1.next;
                  l2=l2.next;
                  r.next=result;
                 r=result;

          }
              if(carry ==1 )
              {
                  ListNode result =new ListNode(1);
                  r.next =result;
              }
              resultantList(tracker.next);
          return tracker;
      }

      public void resultantList(ListNode tracker){
          while(tracker != null)
          {
              System.out.println(tracker.val);
              tracker=tracker.next;
          }
      }


      public int getListLength(ListNode l1){
          int count= 0;
          while(l1.next != null){
              l1=l1.next;
              count++;
          }
          return count+1;
      }
      public ListNode addPadding(int  diff,ListNode n){
          ListNode result= n;
          ListNode l1 =null;
          for(int i=0;i<diff;i++)
          {
               l1 =new ListNode(0);
              n.next = l1;
              n= l1;
          }
       return result;
      }

      public static void main(String[] args) {

          ListNode l1=new ListNode(1);

          l1.next = new ListNode(8);
          l1.next.next = new ListNode(3);

          ListNode l2=new ListNode(7);

         l2.next = new ListNode(1);
        //  l2.next.next  = new ListNode(5);

          ListNode sol=new Solution().addTwoNumbers(l1,l2);

      }

}
