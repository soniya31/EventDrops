import java.util.HashMap;
import java.util.HashSet;

public class LongestSubstringWithKRepeatingCharacters {
    public static void main(String[] args) {
        System.out.println(LongestSubstring("aaabccccdddddeee",3));
    }
    //s = "aaabccccdddddeee", k = 3
//LeetCode – Longest Substring with At Least K Repeating Characters (Java)
    public  static int  LongestSubstring(String str , int k ){

int max=0;
        HashMap<Character , Integer> hm =new HashMap<>();
        HashSet<Character> sanity = new HashSet<>();

        for(int i=0;i<str.length();i++){
            char ch = str.charAt(i);
            if(hm.containsKey(ch)){
                hm.put(ch,hm.get(ch)+1);
            }
            else{
                hm.put(ch,1);
            }
        }

        for(char c :hm.keySet()){
            if(hm.get(c)<k){
                sanity.add(c);
            }
        }

        if(sanity.isEmpty()){
            return str.length();
        }

        int m=0;
        int n =0;
        while( n<str.length()){
            char ch = str.charAt(n);
            if(sanity.contains(ch)){
                if(m!=n) {
                    max = Math.max(max, LongestSubstring(str.substring(m, n), k));
                }
              m=n+1;

            }
            n++;

        }
        if(m!=n)
        max=Math.max(max,LongestSubstring(str.substring(m,n),k));



        return max;
    }
}
