class NodeList{

    int val;
    NodeList next;
    NodeList(int val){
        this.val=val;
    }
}
public class LinkedList {

    public static void main(String[] args) {
        NodeList l1=new NodeList(1);

        l1.next = new NodeList(8);
        l1.next.next = new NodeList(3);

        NodeList l2=new NodeList(7);

        l2.next = new NodeList(1);
      new LinkedList().addTwonumbers(l1,l2);
    }


    public void addTwonumbers(NodeList l1,NodeList l2){
        NodeList result =new NodeList(0);
        NodeList tracker=result;
        int carry =0;
        while(l1 != null && l2!= null){
            int sum = l1.val+l2.val+carry;
            carry= sum>=10?1:0;
            NodeList temp =new NodeList(sum%10);
            result.next = temp;
            result =temp;
            l1 =l1.next;
            l2=l2.next;

        }

        while(l1 != null){

            int sum = carry + l1.val;
                carry= sum>=10?1:0;
                NodeList temp =new NodeList(sum%10);
                result.next = temp;
                result =temp;
                l1 =l1.next;
            }


        while(l2 != null){
            int sum = carry + l2.val;
            carry= sum>=10?1:0;
            NodeList temp =new NodeList(sum%10);
            result.next = temp;
            result =temp;
            l2 =l2.next;
        }

        resultantList(tracker.next);

    }


    public void resultantList(NodeList tracker){
        while(tracker != null)
        {
            System.out.println(tracker.val);
            tracker=tracker.next;
        }
    }


}
